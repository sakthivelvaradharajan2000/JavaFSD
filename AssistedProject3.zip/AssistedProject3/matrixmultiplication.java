package sample;
public class matrixmultiplication {
public static void main(String[] args) {
	int r1 = 2, c1 = 3, r2 = 3, c2 = 2;
    int[][] M1 = { {3, -2, 5}, {3, 0, 4} };
    int[][] M2 = { {2, 3}, {-9, 0}, {0, 4} };
    if(c1==r2) {
    int[][] res = multiply(M1, M2, r1, c1, c2);
    display(res);
    }
    else {
    	System.out.println("Cannot multiply!");
    }
}

public static int[][] multiply(int[][] M1, int[][] M2, int r1, int c1, int c2) {
	int[][] res = new int[r1][c2];
    for(int i = 0; i < r1; i++) {
    	for (int j = 0; j < c2; j++) {
    		for (int k = 0; k < c1; k++) {
    			res[i][j] += M1[i][k] * M2[k][j];
    		}
    	}
    }
    return res;
}
public static void display(int[][] res) {
	System.out.println("Product of two matrices are: ");
    for(int[] row : res) {
    	for (int column : row) {
    		System.out.print(column + " ");
    		}
    	System.out.println();
    	}
    }
}