package sample;

import java.util.Scanner;

public class arrayRotate {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter no. of array elements:");
	int n = sc.nextInt();
	int arr[] = new int[n];
	int temp[] = new int[n];
	System.out.println("Enter array elements:");
	for(int i=0;i<n;i++) {
		arr[i]=sc.nextInt();
	}
	int k=5;
	for(int i=0; i < k; i++){
		temp[i] = arr[n-k+i];
		}
	int j=0;
	for(int i=k; i<n; i++){
		temp[i] = arr[j];
		j++;
		}
	for(int i=0;i<n;i++) {
		System.out.print(temp[i]+" ");
		}		
}
}