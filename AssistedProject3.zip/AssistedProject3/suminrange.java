package sample;

import java.util.Scanner;

public class suminrange {
	public static void main(String[] args) {
		System.out.println("Enter array size: ");
		Scanner sc =new Scanner(System.in);
		int sum = 0;
		int n = sc.nextInt();
		int arr[] =new int[n];
		System.out.println("Enter array elements: ");
		for(int i=0;i<n;i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter left range: ");
		int l = sc.nextInt();
		System.out.println("Enter right range: ");
		int r = sc.nextInt();
		if(l>0 && l<r && r<=n) {
			for(int i=l;i<=r;i++) {
				sum+=arr[i]; 
			}
			System.out.println(sum);
		}
		else {
			System.out.println("Invalid range input");
		}
		
	}

}
