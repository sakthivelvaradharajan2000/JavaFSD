//overloading
public class methodex3 {
	public void area(int l, int b, int h) {
		System.out.println("Area of recatngle is: "+(l*b*h));
	}
	public void area(int b, int h) {
		System.out.println("Area of triangle is: "+(0.5*b*h));
	}
	public void area(int r) {
		System.out.println("Area of circle is: "+(3.14*r*r));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methodex3 m = new methodex3();
		m.area(5);
		m.area(10,15);
		m.area(4,5,6);

	}

}
