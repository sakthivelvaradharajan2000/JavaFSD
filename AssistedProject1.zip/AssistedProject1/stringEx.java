public class stringEx {

	public static void main(String[] args) {
		System.out.println("String Methods");
		
		String sl = new String("Hello World");
		System.out.println(sl.length());

		//substring
		System.out.println(sl.substring(6));

		//String Comparison
		String s2="Hello";
		String s3="Heldo";
		System.out.println(s2.compareTo(s3));

		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());

		//toLowerCase
		String s5="JAVA";
		System.out.println(s5.toLowerCase());
		
		//replace
		String s6 = "Jawa";
		String replace=s2.replace('w', 'v');
		System.out.println(replace);

		//equals
		String s7="Java";
		String s8="JaVa";
		System.out.println(s7.equals(s8));
 
		System.out.println("Creating StringBuffer");
		//Creating StringBuffer and append method
		StringBuffer sbf = new StringBuffer("Hello programmers!");
		sbf.append("Welcome to JAVA!");
		System.out.println(sbf);

		//insert method
		sbf.insert(0, 'H');
		sbf.insert(1, 'i');
		sbf.insert(2, ' ');
		System.out.println(sbf);

		//replace method
		sbf.replace(0, 2, "hEllo");
		System.out.println(sbf);

		//delete method
		sbf.delete(0, 6);
		System.out.println(sbf);
		
		//StringBuilder
		System.out.println("StringBuilder");
		StringBuilder sbd=new StringBuilder("Hello");
		sbd.append(" World");
		System.out.println(sbd);

		System.out.println(sbd.delete(0, 6));

		System.out.println(sbd.insert(0, "Welcome "));

		System.out.println(sbd.reverse());
				
		//conversion	
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Java is a language"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbfr = new StringBuffer(str); 
        sbfr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbfr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbdr = new StringBuilder(str); 
        sbdr.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbdr);              		
	}
}
