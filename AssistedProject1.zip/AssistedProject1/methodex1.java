
public class methodex1 {
	public int addnum(int num1, int num2) {
		return num1+num2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int res;
		methodex1 m = new methodex1();
		res = m.addnum(50,30);
		System.out.println("Addition of two numbers is "+res);

	}

}
