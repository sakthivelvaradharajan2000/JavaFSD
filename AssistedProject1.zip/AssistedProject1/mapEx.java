import java.util.*;
public class mapEx {

	public static void main(String[] args) {
		//Hash map
		System.out.println("Hashmap elements: ");
		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	    hm.put(1,"Aaron");    
	    hm.put(2,"Arun");    
	    hm.put(3,"Swetha");
	    hm.put(4,"Ramya");
	    for(Map.Entry i:hm.entrySet()){    
	     System.out.println(i.getKey()+" "+i.getValue());    
	     }
	      
	    //Hash Table
	    System.out.println("HashTable elements: "); 
	    Hashtable<Integer,String> ht=new Hashtable<Integer,String>(); 
	    ht.put(1,"Aadhi");  
	    ht.put(2,"Athreya");  
	    ht.put(3,"Nishanth");  
	    ht.put(4,"Sandy"); 	     
	    for(Map.Entry i:ht.entrySet()){    
	    	System.out.println(i.getKey()+" "+i.getValue());    
	    	}
	    
	    //TreeMap
	    System.out.println("TreeMap elements: "); 
	    TreeMap<Integer,String> tm=new TreeMap<Integer,String>();    
	    tm.put(1,"Arun");    
	    tm.put(2,"Balaji");    
	    tm.put(3,"Kumar");  
	    tm.put(4,"Venki");
	    for(Map.Entry i:tm.entrySet()){    
	     System.out.println(i.getKey()+" "+i.getValue());    
	    }    
	      
   }  
}

