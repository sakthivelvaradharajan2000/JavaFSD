public class arrayEx {

	public static void main(String[] args) {
		//1D array
		int arr1[]= {13, 46, 25, 99, 76, 68, 138,55};
		for(int i=0;i<arr1.length;i++) {
			System.out.println("Elements of array a: "+arr1[i]);
		}


		//multidimensional array
		int[][] arr2 = {
				{12, 88, 16, 98}, 
				{33, 66, 59, 73},
				{24, 67, 83}};
		
        System.out.println("Length of row 1: " + arr2[0].length);
        System.out.println("Length of row 2: " + arr2[1].length);
        System.out.println("Length of row 3: " + arr2[2].length);
		}
}