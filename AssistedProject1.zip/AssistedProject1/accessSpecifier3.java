package pack1;

public class accessSpecifier3 {
	protected void display() {
		System.out.println("This is protected access specifier");
	}

}
