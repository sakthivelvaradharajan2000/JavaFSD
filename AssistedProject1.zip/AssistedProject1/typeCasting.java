package Practice_Project2;

public class typeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Implicit type Casting");
		byte a = 100;
		System.out.println("Byte value: "+a);
		short b = a;
		System.out.println("Short value: "+b);
		int c = b;
		System.out.println("Integer value: "+c);
		long d = c;
		System.out.println("Long value: "+d);
		float e = d;
		System.out.println("Float value: "+e);
		double f = e;
		System.out.println("Double value: "+f);
		System.out.println("Explicit type Casting");
		double g = 20.56;
		System.out.println("Double value: "+g);
		float h = (float)g;
		System.out.println("Float value: "+h);
		long i = (long)h;
		System.out.println("Long value: "+i);
		int j = (int)i;
		System.out.println("Integer value: "+j);
		short k = (short)j;
		System.out.println("Short value: "+k);
		byte l = (byte)k;
		System.out.println("Byte value: "+l);
		
	}

}
