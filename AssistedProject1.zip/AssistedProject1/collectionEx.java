import java.util.*;

public class collectionEx {

	public static void main(String[] args) {
		//Array List
		System.out.println("ArrayList:");
		ArrayList<String> food=new ArrayList<String>();   
	    food.add("Idli");
	    food.add("Dosa"); 
	    food.add("Naan");
	    food.add("Vada");
	    System.out.println(food);  
		
		//Vector
	    System.out.println("Vector: ");
	    Vector<Integer> vec = new Vector();
	    vec.addElement(11); 
	    vec.addElement(22);
	    vec.addElement(33); 
	    vec.addElement(44); 
	    System.out.println(vec);
		
		//Linked list
	    System.out.println("LinkedList: ");
	    LinkedList<String> city=new LinkedList<String>();  
	    city.add("New York");  
	    city.add("London");  
	    city.add("Mumbai");
	    city.add("Sydney");
	    Iterator<String> itr=city.iterator();  
	    while(itr.hasNext()){ 
	       System.out.println(itr.next());  
	    }
	       
	       
	    //Hash set
	    System.out.println("HashSet: ");
	    HashSet<Integer> hs=new HashSet<Integer>();  
	    hs.add(1);  
	    hs.add(7);  
	    hs.add(9);
	    hs.add(13);
	    System.out.println(hs);
	       
	    //Linked hash set
	    System.out.println("LinkedHashSet");
	    LinkedHashSet<String> lhs=new LinkedHashSet<String>();  
	    lhs.add("hello");  
	    lhs.add("Congrats");  
	    lhs.add("How are you?");
	    lhs.add("Great");	       
	    System.out.println(lhs);
	      	} 
	      
	}




