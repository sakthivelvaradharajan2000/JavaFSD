//Anonymous inner class

abstract class AnonymousInnerClass {
	   public abstract void display();
	}


	public class innerClass3 {

	public static void main(String[] args) {
	AnonymousInnerClass ic3 = new AnonymousInnerClass() {

	         public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      ic3.display();
	   }
	}