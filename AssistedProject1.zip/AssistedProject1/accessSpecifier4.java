package pack2;
import pack1.*;

public class accessSpecifier4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pubAs puacs = new pubAs();
		puacs.display();
	}

}
