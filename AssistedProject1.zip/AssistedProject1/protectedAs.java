package pack2;
import pack1.*;

public class protectedAs extends accessSpecifier3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		protectedAs pro = new protectedAs();
		pro.display();
	}

}
