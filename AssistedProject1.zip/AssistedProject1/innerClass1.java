public class innerClass1 {

	 private String a="Hello"; 
	 
	 class Inner{  
	  void display(){System.out.println(a+", Hope you are doing well!");}  
	 }  


	public static void main(String[] args) {

		innerClass1 ic1 =new innerClass1();
		innerClass1.Inner ic = ic1.new Inner();  
		ic.display();  
	}
}