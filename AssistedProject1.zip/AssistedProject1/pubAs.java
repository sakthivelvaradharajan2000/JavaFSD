package pack1;

public class pubAs {
	public void display() {
		System.out.println("This is public access specifier");
	}
}
