package pack1;

class aS1{
	void display() {
		System.out.println("This is default access specifier!");
	}
}

public class accessSpecifier1 {
	public static void main(String[] args) {
		System.out.println("Default Access Specifier");
		aS1 as = new aS1();
		as.display();
	}

}
