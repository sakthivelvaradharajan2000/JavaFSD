package pack1;




class privateaS{
	private void display() {
		System.out.println("This is private access specifier");
	}
}
public class accessSpecifier2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Private Access Specifier");
		privateaS pas = new privateaS();
		//pas.display();
		/* This cannot be done because display method is private
		 *  and can be accessed by privateaS class level only.
		 *  If we run this program, we will get "The method display() from the type privateaS is not visible"
		 */

	}

}
