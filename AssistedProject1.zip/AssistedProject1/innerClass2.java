public class innerClass2 {

String a="Inner Class";

 void display(){  
	 class Innerclass{  
		 void show(){
			 System.out.println(a);
		 }  
  }  
  
  Innerclass ic =new Innerclass();  
  ic.show();  
 }  

public static void main(String[] args) {
	innerClass2  ic2=new innerClass2 ();  
	ic2.display();  
	}
}
