//call by value
public class methodex2 {
	int v = 150;
	int op(int v) {
		v=v*10/100;
		return v;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methodex2 m = new methodex2();
		System.out.println("Before operation, value is "+m.v);
		m.op(100);
		System.out.println("After operation, value is "+m.v);// we will get 150
		System.out.println("Value is "+m.op(100));// we will get 10
		

	}

}
