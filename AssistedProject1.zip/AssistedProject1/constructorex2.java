//parameterized constructor
class Students{
	int id;
	String name;
	Students(int i, String n){
		id =i;
		name = n;
	}
	void display() {
		System.out.println(id+" "+name);
	}
}
public class constructorex2 {
	public static void main(String[] args){
		Students s1 = new Students(1,"Aditya");
		Students s2 = new Students(2,"Arun");
		Students s3 = new Students(3,"Athreya");
	
		
		s1.display();
		s2.display();
		s3.display();
		
		
	}

}
