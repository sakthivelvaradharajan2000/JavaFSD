package sample;

public class bubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {92,12,56,44,86,67};
		int temp = 0;
        for(int i=0;i<arr.length;i++){
            for (int j=1;j<arr.length;j++){
                if(arr[j-1]>arr[j]){
                temp = arr[j-1];
                arr[j-1]= arr[j];
                arr[j]= temp;
                }
            }
        }
        for(int i=0;i<arr.length;i++){

            System.out.print(arr[i]+" ");
        }
}
}