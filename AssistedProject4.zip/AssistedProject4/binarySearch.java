package sample;

import java.util.Scanner;

public class binarySearch {
	public static boolean search(int arr[], int k) {
		boolean res = false;
		int start = 0;
		int end = arr.length-1;
		int mid = 0;
		while(start<=end) {
			mid = (start+end)/2;
			if(arr[mid]==k) {
				res=true;
				break;
			}
			else if(arr[mid]<k) {
				start = mid+1;
			}
			else {
				end = mid-1;
			}
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {55,44,77,33,22,33,11,99,88};
		int temp;
		for(int i=0;i<arr.length;i++){
			for(int j=i+1;j<arr.length;j++){
				if(arr[i]>arr[j]){
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter element to be searched:");
		int k = sc.nextInt();
		boolean res = search(arr,k);
		if(res==true) {
			System.out.println("Element is present!");
		}
		else {
			System.out.println("Element is not present!");
		}
	}

}
