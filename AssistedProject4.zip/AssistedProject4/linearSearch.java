package sample;

import java.util.Scanner;

public class linearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {1,2,3,4,5,6,7,8,9,10};
		int flag = 0,b=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter elemnt to be searched:");
		int a =sc.nextInt();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==a) {
				flag = 1;
				b=i;
				break;
			}
			else {
				flag=0;
			}
		}
		if(flag == 1) {
			System.out.println("Element "+a+" found at "+(b+1)+"th position");
		}
		else {
			System.out.println("Element "+a+" not found!");
		}

	}

}
