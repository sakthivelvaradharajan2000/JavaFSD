package sample;

public class insertionSoert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {35,14,65,43,82,25};
		for(int j=1;j<arr.length;j++){
		    int key = arr[j];
		    int i=j-1;
		    while ((i>-1) && (arr[i]>key)){
		        arr[i+1]=arr[i];
		        i--;
		    	}
		    arr[i+1]=key;
		    }
		for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
	}
}
