class vehicle{
	public String type;
	public int maxspeed;
	public vehicle(String type, int maxspeed){
		this.type = type;
		this.maxspeed = maxspeed;
	}
	
}
class car extends vehicle{
	public int load;
	public int mileage;
	public car(String type, int maxspeed, int l, int m) {
		super(type, maxspeed);
		load = l;
		mileage = m;
	}
	@Override
	public String toString() {
		return("Type: "+type+" Max Speed: "+maxspeed+" Mileage: "+mileage+" with load: "+load);
	}
}
public class inheritanceEx {
	public static void main(String[] args) {
		car c1 = new car("Sedan", 180, 500, 20);
		System.out.println(c1.toString());
	}
}
