public class finallyEx{
	public static void main(String[] args){
		int a=4,b=0,res=0;
		try{
			res = a / b;
			}
        catch(ArithmeticException aex){
            System.out.println("Error: " + aex.getMessage());
            }
		finally{
            System.out.println("The result is: " + res);
            }
        }
}