public class trycatchEx {
    public static void main(String args[]) {
        int[] arr = new int[5];
        try 
        {
        	arr[1] = 9;
            arr[9] = 8;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }
        finally 
        {
            System.out.println("The array is of size " + arr.length);
        }
    }
}