class MyException extends Exception{
   String s1;
   MyException(String s2) {
	s1=s2;
   }
   public String toString(){ 
	return ("My Custom Exception Occurred: "+s1);
   }
}
class exceptionhandlerEx{
   public static void main(String args[]){
	try{
		System.out.println("In try block");
		throw new MyException("Custom exception");
	}
	catch(MyException exp){
		System.out.println("In catch block");
		System.out.println(exp);
	}
   }
}