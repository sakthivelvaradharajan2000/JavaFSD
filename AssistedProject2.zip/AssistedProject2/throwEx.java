public class throwEx{
	public static void main(String[] args){
		int a=4,b=0,res;
		try{
			if(b==0) {        
				throw(new ArithmeticException("Can't divide by zero."));
			}
            else{
                res = a / b;
                System.out.println("The result is: " + res);
                }
            }
        catch(ArithmeticException aex){
        	System.out.println("Error : " + aex.getMessage());
            }

        System.out.println("End of program");
        }
}