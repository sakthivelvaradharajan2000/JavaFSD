class Encap 
{ 
    private String Name; 
    private int Roll; 
    private int Age;
    public String getName()  
    { 
      return Name; 
    } 
    public int getRoll()  
    { 
       return Roll; 
    } 
    public int getAge()  
    { 
      return Age; 
    } 

    public void setName(String newName) 
    { 
      Name = newName; 
    } 
    public void setRoll( int newRoll)  
    { 
      Roll = newRoll; 
    } 
    public void setAge( int newAge) 
    { 
      Age = newAge; 
    } 
}
public class encapsulationEx
{     
    public static void main (String[] args)  
    { 
        Encap e = new Encap(); 
        e.setName("Ram"); 
        e.setAge(13); 
        e.setRoll(21); 
        System.out.println("My name: " + e.getName()); 
        System.out.println("My age: " + e.getAge()); 
        System.out.println("My roll: " + e.getRoll());      
    } 
}