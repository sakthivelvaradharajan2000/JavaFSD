public class throwsEx{
	void Div() throws ArithmeticException{
		int a=4,b=0,res;
		res = a / b;
        System.out.println("The result is: " + res);
        }
    public static void main(String[] args){
    	throwsEx t = new throwsEx();
    	try{
    		t.Div();
    		}
        catch(ArithmeticException aex){
        	System.out.println("Error : " + aex.getMessage());
            }
        System.out.println("End of program");
        }
}